<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
<div class="md:col-span-2 space-y-6">
<div class="bg-white p-6 rounded-lg shadow">
<h1 class="text-2xl font-bold text-slate-900"><?php echo e($student->full_name); ?></h1>
<p class="text-xs text-slate-500 font-mono mt-1">ID: <?php echo e($student->student_number); ?> |
Email: <?php echo e($student->email); ?></p>
</div>
<div class="bg-white p-6 rounded-lg shadow">
<h2 class="text-lg font-bold mb-4">Enrolled Courses (<?php echo e($student->courses->count()); ?>)</h2>
<div class="space-y-3">
<?php $__empty_1 = true; $__currentLoopData = $student->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="flex justify-between items-center p-3 bg-slate-50 border rounded">
<div>
<span class="font-bold text-sm"><?php echo e($course->code); ?></span>
<p class="text-xs text-slate-600"><?php echo e($course->title); ?> (<?php echo e($course->credits); ?>

Credits)</p>
</div>
<span class="text-xs bg-blue-100 text-blue-800 font-bold px-2.5 py-1 rounded">Enrolled</span>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p class="text-sm text-slate-500">Student is not currently enrolled in any
course.</p>
<?php endif; ?>
</div>
</div>
</div>
<div class="bg-white p-6 rounded-lg shadow h-fit">
<h2 class="text-lg font-bold mb-4">Enroll in Course</h2>
<?php if($availableCourses->count() > 0): ?>
<form action="<?php echo e(route('students.enroll', $student->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<div class="mb-4">
<label class="block text-sm font-medium mb-1">Select Course</label>
<select name="course_id" required class="w-full border rounded p-2 text-sm">
<option value="">-- Choose Course --</option>
<?php $__currentLoopData = $availableCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($c->id); ?>"><?php echo e($c->code); ?> - <?php echo e($c->title); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>
</div>
<button type="submit" class="w-full bg-blue-600 text-white font-bold py-2 rounded hover:bg-blue-700 text-sm">Enroll Student</button>
</form>
<?php else: ?>
<p class="text-sm text-slate-500">No additional courses available for enrollment.</p>
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-system-new\resources\views/students/show.blade.php ENDPATH**/ ?>