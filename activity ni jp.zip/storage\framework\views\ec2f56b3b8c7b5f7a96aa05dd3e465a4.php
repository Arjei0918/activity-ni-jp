<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto bg-white p-6 rounded-lg shadow">
<h1 class="text-xl font-bold mb-4">Create Course Activity</h1>
<?php if($errors->any()): ?>
<div class="mb-4 p-3 bg-red-100 border-l-4 border-red-500 text-red-700 text-sm">
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>• <?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<form action="<?php echo e(route('activities.store')); ?>" method="POST">
<?php echo csrf_field(); ?>

<div class="mb-4">
<label class="block text-sm font-medium mb-1">Target Course</label>
<select name="course_id" required class="w-full border rounded p-2 text-sm focus:ring focus:ring-blue-200">
<option value="">-- Select Course --</option>
<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($course->id); ?>"><?php echo e($course->code); ?> - <?php echo e($course->title); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
<div class="mb-4">
<label class="block text-sm font-medium mb-1">Activity Title</label>
<input type="text" name="title" value="<?php echo e(old('title')); ?>" required class="w-full border rounded p-2 text-sm focus:ring focus:ring-blue-200">
</div>
<div class="mb-4">
<label class="block text-sm font-medium mb-1">Instructions / Description</label>
<textarea name="description" rows="4" required class="w-full border rounded p-2 text- sm focus:ring focus:ring-blue-200"><?php echo e(old('description')); ?></textarea>
</div>
<div class="grid grid-cols-2 gap-4 mb-6">
<div>
<label class="block text-sm font-medium mb-1">Max Points</label>
<input type="number" name="max_points" value="<?php echo e(old('max_points', 100)); ?>" required class="w-full border rounded p-2 text-sm focus:ring focus:ring-blue-200">
</div>
<div>
<label class="block text-sm font-medium mb-1">Due Date & Time</label>
<input type="datetime-local" name="due_date" value="<?php echo e(old('due_date')); ?>" required class="w-full border rounded p-2 text-sm focus:ring focus:ring-blue-200">
</div>
</div>
<button type="submit" class="w-full bg-blue-600 text-white font-bold py-2 rounded hover:bg-blue-700 text-sm">Post Activity</button>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-system-new\resources\views/activities/create.blade.php ENDPATH**/ ?>