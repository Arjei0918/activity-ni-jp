
<?php

use App\Http\Controllers\StudentController;
use App\Http\Controllers\ActivityController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('students.index');
});

// Student Management
Route::resource('students', StudentController::class)
    ->only(['index', 'create', 'store', 'show', 'destroy']);

Route::post('students/{student}/enroll',
    [StudentController::class, 'enroll'])
    ->name('students.enroll');

// Activity Management
Route::resource('activities', ActivityController::class)
    ->only(['index', 'create', 'store', 'show']);

Route::post('activities/{activity}/submit',
    [ActivityController::class, 'submit'])
    ->name('activities.submit');
