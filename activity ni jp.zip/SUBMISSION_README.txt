School Management System
Submitted by: Arjei Lacayanga

Requirements:
- PHP with SQLite extensions
- Composer
- Laravel dependencies

Installation:
1. Extract the ZIP.
2. Open PowerShell in the project folder.
3. Run: composer install
4. Run: Copy-Item .env.example .env
5. Set DB_CONNECTION=sqlite in .env
6. Run: php artisan key:generate
7. Run: php artisan migrate
8. Run: php artisan serve
9. Visit http://127.0.0.1:8000

The database/database.sqlite file is included
if present in the original project.
