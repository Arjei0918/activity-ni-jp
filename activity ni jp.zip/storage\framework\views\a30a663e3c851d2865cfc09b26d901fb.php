<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
<div class="md:col-span-2 space-y-6">
<div class="bg-white p-6 rounded-lg shadow">
<span class="text-xs font-mono bg-blue-100 text-blue-800 px-2 py-1 rounded font- bold"><?php echo e($activity->course->code); ?></span>
<h1 class="text-2xl font-bold text-slate-900 mt-2"><?php echo e($activity->title); ?></h1>
<p class="text-xs text-slate-500 mt-1">Due: <?php echo e(\Carbon\Carbon::parse($activity->due_date)->format('F d, Y h:i A')); ?> | Max Points: <?php echo e($activity->max_points); ?></p>
<hr class="my-4">
<div class="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
<?php echo e($activity->description); ?>

</div>
</div>
<div class="bg-white p-6 rounded-lg shadow">
<h2 class="text-lg font-bold mb-4">Submitted Works (<?php echo e($activity->submissions->count()); ?>)</h2>
<div class="space-y-4">
<?php $__empty_1 = true; $__currentLoopData = $activity->submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="border p-4 rounded-lg bg-slate-50">
<div class="flex justify-between items-center mb-2">
<span class="font-bold text-sm text-slate-800"><?php echo e($sub->student->full_name); ?></span>
<span class="text-xs text-slate-500"><?php echo e(\Carbon\Carbon::parse($sub->submitted_at)->diffForHumans()); ?></span>
</div>
<p class="text-sm text-slate-600 bg-white p-3 rounded border font-mono"><?php echo e($sub->submission_text); ?></p>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p class="text-sm text-slate-500">No student submissions recorded yet.</p>
<?php endif; ?>
</div>
</div>
</div>
<div class="bg-white p-6 rounded-lg shadow h-fit">
<h2 class="text-lg font-bold mb-4">Turn In Activity</h2>
<?php if($pendingStudents->count() > 0): ?>
<form action="<?php echo e(route('activities.submit', $activity->id)); ?>" method="POST">
<?php echo csrf_field(); ?>

<div class="mb-4">
<label class="block text-sm font-medium mb-1">Select Student</label>
<select name="student_id" required class="w-full border rounded p-2 text-sm focus:ring focus:ring-blue-200">
<option value="">-- Enrolled Students --</option>
<?php $__currentLoopData = $pendingStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($student->id); ?>"><?php echo e($student->student_number); ?> - <?php echo e($student->full_name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
<div class="mb-4">
<label class="block text-sm font-medium mb-1">Submission Text / Answer
Link</label>
<textarea name="submission_text" rows="4" placeholder="Type answer or paste link here..." required class="w-full border rounded p-2 text-sm focus:ring focus:ring-blue- 200"></textarea>
</div>
<button type="submit" class="w-full bg-green-600 text-white font-bold py-2 rounded hover:bg-green-700 text-sm">Submit Work</button>
</form>
<?php else: ?>
<p class="text-sm text-slate-500">All enrolled students have submitted or no enrolled
students found for this course.</p>
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-system-new\resources\views/activities/show.blade.php ENDPATH**/ ?>